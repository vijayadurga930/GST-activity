 package com.cg.eis.main;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class MainUi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner(System.in);
EmployeeService employeeService=new EmployeeServiceImpl();
Map<Integer, Employee> employee=new HashMap<>();
boolean continueValue=false;
String continueChoice;


boolean flag=false;
do {
	System.out.println("1.Add employee details\n 2.Display employee details");
	System.out.println("select a option");
	try {
		int option=scanner.nextInt();
		flag=true;
		switch (option) {
		case 1:{
			String name=null;
			boolean val=false;
		
			do{
				System.out.println("enter name of the employee");
				
			/*try {
				 name= scanner.next();
				
				employeeService.validateName(name);
				val=true;
				
			} catch (InputMismatchException e) {
				// TODO: handle exception
				val=false;
				System.err.println("name must be in leters");
			}catch (EmployeeException e) {
				// TODO: handle exception
				val=false;
				System.out.println(e.getMessage());
			}*/
				try {
					name= scanner.next();
					
					employeeService.validateName(name);
					val=true;
				
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					val=false;
					System.out.println(e.getMessage());
				}
			
			}while(!val);
			System.out.println("enter the employee designation");
			String designation=scanner.next();
		
			double salary=0.000;
			boolean salflag=false;
			do {
				System.out.println("enter the employee salary");
				try {
					
					salary=scanner.nextDouble();
					
						employeeService.validateSalary(salary);
						salflag=true;
						
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				catch (InputMismatchException e) {
					salflag=false;
					System.out.println("salary must be in digits");
					
				}
			} while (!salflag);
			
			int id=0;
			try {
				 id=employeeService.generateId();
				System.out.println(" succesfully regiestered with id :"+ id);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println("not regiestered succesfully");
			}
			String scheme=null;
			try {
				 scheme=employeeService.AssignScheme(salary, designation);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println("no scheme available for given details");
			}
			
			
			employee.put(id, new Employee(name, designation, scheme, salary));
			
			
		}break;
		
		case 2:{
			try {
				if(employee!=null)
				System.out.println("employee details" + employee);
			} catch (Exception e) {
				// TODO: handle exception
				System.err.println("no details to display");
			}
			
		}break;
		default:
		{
			flag=false;
			System.out.println("choice must between 1 and 2");
		}break;
		}
		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = false;
				flag=false;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				flag=true;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = true;
				continue;
			}
		} while (continueValue);
	} catch (InputMismatchException e) {
		// TODO: handle exception
		flag=true;
		System.out.println("choice must be in digits");
	}
}while(!flag);
	}

}
