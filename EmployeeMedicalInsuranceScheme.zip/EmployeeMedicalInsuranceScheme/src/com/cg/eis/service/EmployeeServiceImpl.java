package com.cg.eis.service;

import java.util.regex.Pattern;

import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public String AssignScheme(double salary, String designation) throws EmployeeException {
		// TODO Auto-generated method stub
		String insuranceScheme=null;
		if(salary<5000 && designation.equals("clerk"))
		{
			insuranceScheme="no scheme assigned";
		}
		if(salary>5000 && salary<20000 && designation.equals("System Asssociate"))
		{
			insuranceScheme="Scheme C";
		}
		if(salary>=20000 && salary<40000 && designation.equals("programmer"))
		{
			insuranceScheme="Scheme B";
		}
		if(salary>=40000 && designation.equals("manager") && salary<=90000)
		{
			insuranceScheme="Scheme A";
		}
		else
		{
			throw new EmployeeException("salary must be less than 90000");
		}
		return insuranceScheme;
	}

	@Override
	public int generateId() throws EmployeeException {
		// TODO Auto-generated method stub
		double generatedId;
		generatedId=Math.random()*1000;
		int id=(int)generatedId;
		return id;
	}

	@Override
	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		boolean result=false;
		String pattern= "[A-Z]{1}[a-zA-Z]{4,}";
		
			if(!Pattern.matches(pattern, name))
			{
				 
				 throw new EmployeeException("name should be start wiith capital letter and minimum 5 characters should present");
			}
			else
			{
				result=true;
			}
		
		
		return result;
	}

	@Override
	public boolean validateSalary(double salary) throws EmployeeException {
		// TODO Auto-generated method stub
		boolean salFlag=false;
		try {
			if(salary<90000);
			salFlag=true;
			
		} catch (Exception e) {
			salFlag=false;
throw new EmployeeException("sal must be less than 90000");


		}
		return salFlag;
	}

}
