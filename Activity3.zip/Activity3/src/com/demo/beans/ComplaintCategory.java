package com.demo.beans;

public class ComplaintCategory {
private String complaintNo;
private  ComplaintCategory complaintCategory;
private String complaintDescription;
private String complaintPriority;
private String ComplaintStatus;
private String comments;
public ComplaintCategory() {
	super();
	// TODO Auto-generated constructor stub
}
public ComplaintCategory(String complaintNo, ComplaintCategory complaintCategory, String complaintDescription,
		String complaintPriority, String complaintStatus, String comments) {
	super();
	this.complaintNo = complaintNo;
	this.complaintCategory = complaintCategory;
	this.complaintDescription = complaintDescription;
	this.complaintPriority = complaintPriority;
	this.ComplaintStatus = complaintStatus;
	this.comments = comments;
}
public ComplaintCategory(int registeredId, String description, String priority, String status, String comments2) {
	// TODO Auto-generated constructor stub
	this.complaintNo=String.valueOf(registeredId);
	this.complaintDescription=description;
	this.complaintPriority=priority;
	this.ComplaintStatus=status;
	this.comments=comments2;
}
public String getComplaintNo() {
	return complaintNo;
}
public void setComplaintNo(String complaintNo) {
	this.complaintNo = complaintNo;
}
public ComplaintCategory getComplaintCategory() {
	return complaintCategory;
}
public void setComplaintCategory(ComplaintCategory complaintCategory) {
	this.complaintCategory = complaintCategory;
}
public String getComplaintDescription() {
	return complaintDescription;
}
public void setComplaintDescription(String complaintDescription) {
	this.complaintDescription = complaintDescription;
}
public String getComplaintPriority() {
	return complaintPriority;
}
public void setComplaintPriority(String complaintPriority) {
	this.complaintPriority = complaintPriority;
}
public String getComplaintStatus() {
	return ComplaintStatus;
}
public void setComplaintStatus(String complaintStatus) {
	this.ComplaintStatus = complaintStatus;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
@Override
public String toString() {
	return "ComplaintCategory [complaintNo=" + complaintNo 
			+ ", complaintDescription=" + complaintDescription + ", complaintPriority=" + complaintPriority
			+ ", ComplaintStatus=" + ComplaintStatus + ", comments=" + comments + "]";
}


}
