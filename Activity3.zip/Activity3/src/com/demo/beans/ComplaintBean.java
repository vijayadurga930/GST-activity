package com.demo.beans;

public class ComplaintBean {
private String complaintCategoryId;
private String categoryName;
public ComplaintBean() {
	super();
	// TODO Auto-generated constructor stub
}
public ComplaintBean(String complaintCategoryId, String categoryName) {
	super();
	this.complaintCategoryId = complaintCategoryId;
	this.categoryName = categoryName;
}
public String getComplaintCategoryId() {
	return complaintCategoryId;
}
public void setComplaintCategoryId(String complaintCategoryId) {
	this.complaintCategoryId = complaintCategoryId;
}
public String getCategoryName() {
	return categoryName;
}
public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
}
@Override
public String toString() {
	return "ComplaintBean [complaintCategoryId=" + complaintCategoryId + ", categoryName=" + categoryName + "]";
}

}
