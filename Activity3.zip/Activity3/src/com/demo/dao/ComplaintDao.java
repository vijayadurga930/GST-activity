package com.demo.dao;

import java.util.List;

import com.demo.beans.ComplaintBean;
import com.demo.beans.ComplaintCategory;
import com.demo.exception.ComplaintException;

public interface ComplaintDao {
	boolean raiseNewComplaint(ComplaintBean complaintBean)throws ComplaintException;
	List<ComplaintCategory> listComplaintCategory()throws ComplaintException;
}
