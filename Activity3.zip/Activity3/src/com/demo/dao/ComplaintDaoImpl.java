package com.demo.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.demo.beans.ComplaintBean;
import com.demo.beans.ComplaintCategory;
import com.demo.exception.ComplaintException;

public class ComplaintDaoImpl implements ComplaintDao {
	private static Map<String, String> complaintCategory= new HashMap<>();
	public static Map<String, String> getComplaintCategoryEnteries(){
		complaintCategory.put("C001", "Software problem");
		complaintCategory.put("C002", "Hardware problem");
		complaintCategory.put("C004", "Internet problem");
		complaintCategory.put("C003", "Other issues");
		return complaintCategory;
		
	}

	@Override
	public boolean raiseNewComplaint(ComplaintBean complaintBean) throws ComplaintException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ComplaintCategory> listComplaintCategory() throws ComplaintException {
		// TODO Auto-generated method stub
//		Collection<String> collection=complaintCategory.values();
//		
//		List<ComplaintCategory> list1=new ArrayList<>();
//		list1.add(collection);
		return null;
	}

}
