package com.demo.exception;

public class ComplaintException extends Exception {

	public ComplaintException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
