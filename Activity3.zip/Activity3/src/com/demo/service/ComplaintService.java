package com.demo.service;

import java.util.List;
import java.util.Map;

import com.demo.beans.ComplaintCategory;
import com.demo.exception.ComplaintException;

public interface ComplaintService {
	boolean raiseNewComplaint(ComplaintCategory complaintCategory)throws ComplaintException;
	List<ComplaintCategory> listComplaintCategory()throws ComplaintException;
	boolean validPriority(String priority)throws ComplaintException;
	Map<String, String> getComplaintCategoryEnteries()throws ComplaintException;
	boolean ComplaintStatusDisplay(String description, String priority) throws ComplaintException;
	int registerId()throws ComplaintException;

}
