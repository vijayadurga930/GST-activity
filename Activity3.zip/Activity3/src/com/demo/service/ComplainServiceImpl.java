package com.demo.service;

import java.util.List;
import java.util.Map;

import com.demo.beans.ComplaintCategory;
import com.demo.dao.ComplaintDao;
import com.demo.dao.ComplaintDaoImpl;
import com.demo.exception.ComplaintException;

public class ComplainServiceImpl implements ComplaintService {
ComplaintDao dao= new ComplaintDaoImpl();
ComplaintCategory complaint= new ComplaintCategory();
	@Override
	public boolean raiseNewComplaint(ComplaintCategory complaintCategory) throws ComplaintException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ComplaintCategory> listComplaintCategory() throws ComplaintException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validPriority(String priority) throws ComplaintException {
		// TODO Auto-generated method stub
		boolean validPriority=false;
		if(priority.equalsIgnoreCase("high")||priority.equalsIgnoreCase("low"))
			validPriority=true;
		else
			throw new ComplaintException("invalid priority");
		return validPriority;
	}

	@Override
	public Map<String, String> getComplaintCategoryEnteries() throws ComplaintException {
		// TODO Auto-generated method stub
		return ComplaintDaoImpl.getComplaintCategoryEnteries();
	}

	@Override
	public boolean ComplaintStatusDisplay(String description, String priority) throws ComplaintException {
		boolean p=false;
		if(priority.equalsIgnoreCase("high"))
		{
			p=true;
			complaint.setComplaintStatus("ur problem is registeredtered");
			complaint.setComments("ur complaint will be rectified soon");
		}
		else if(priority.equalsIgnoreCase("low"))
		{
			p=true;
			complaint.setComplaintStatus("ur problem is registered");
			complaint.setComments("ur complaint will take time to be rectified");
		}
		else
			p=false;
		return p;
	}

	@Override
	public int registerId() throws ComplaintException {
		double registeredId=Math.random()*1000;
		int id=(int)registeredId;
		return id;
	}

}
