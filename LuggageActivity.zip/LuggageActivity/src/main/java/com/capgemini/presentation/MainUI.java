package com.capgemini.presentation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.beans.Luggage;
import com.capgemini.exception.LuggageException;
import com.capgemini.service.LuggageService;
import com.capgemini.service.LuggageServiceImpl;

public class MainUI {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		LuggageService service = new LuggageServiceImpl();
		Map<Integer, Luggage> map = new HashMap<>();
		List<Luggage> list = new ArrayList<>();
		Luggage luggage = null;
		boolean choiceFlag = false;
		do {
			System.out.println("***WELCOME***");
			System.out.println("1.add Weight \n 2.display by id \n 3.display all");
			try {
				int choice = scanner.nextInt();
				switch (choice) {
				case 1: {
					float weight = 0;
					boolean validateWeight = false;
					do {
						try {
							scanner.nextLine();
							System.out.println("Enter weight in kgs");
							weight = scanner.nextFloat();
							service.validateWeight(weight);
							validateWeight = true;
						} catch (InputMismatchException e) {
							System.err.println("please enter valid weight");
						} catch (LuggageException e) {
							System.out.println(e.getMessage());
						}

					} while (!validateWeight);
					float distance = 0;
					boolean validateDistance = false;
					do {
						try {
							scanner.nextLine();
							System.out.println("Enter distance in KM");
							distance = scanner.nextFloat();
							service.validateDistance(distance);
							validateDistance = true;
						} catch (InputMismatchException e) {
							System.err.println("please enter valid distance");
						} catch (LuggageException e) {
							System.out.println(e.getMessage());
						}

					} while (!validateDistance);
					try {
						double charge = service.charge(weight, distance);
						double CGSt = service.Tax(charge);
						double SGST = service.Tax(charge);
						double totalCharge = service.getTotalCharge(charge, CGSt, SGST);
						int id = service.getGeneratedId();
						luggage = new Luggage(weight, distance, charge, CGSt, SGST, totalCharge);
						service.addWeight(id, luggage);
						System.out.println("luggage added with registered id:" + id);
					} catch (LuggageException e) {
						System.out.println(e.getMessage());
					}

				}
					break;
				case 2: {

					try {
						scanner.nextLine();
						System.out.println("enter Id to be displayed:");
						int id = scanner.nextInt();
						list = service.getListById(id);
						System.out.println(list);
					} catch (LuggageException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
					break;
				case 3: {
					try {
						System.out.println("whole list");
						map = service.getList();
						System.out.println(map);
					} catch (LuggageException e) {
						System.out.println(e.getMessage());


					}

				}
					break;

				default:{
					System.err.println("please enter 1,2,3");
				}
					break;
				}
				boolean continueFlag1=false;
				String continuechoice1;
				do {
					System.out.println("do u want to continue yes or no");
					continuechoice1 = scanner.next();
					if (continuechoice1.equalsIgnoreCase("yes")) {
						continueFlag1 = false;
						choiceFlag =true;
						break;
					} else if (continuechoice1.equalsIgnoreCase("no")) {
						continueFlag1 = false;
						choiceFlag = false;
						break;
					} else {
						System.out.println("enter yes or no");
						continueFlag1 = true;

					}
				} while (continueFlag1);
			} catch (InputMismatchException e) {
				System.err.println("choice must be in digits");
			}

		} while (choiceFlag);

	}

}
