package com.capgemini.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Luggage;

public class LuggageRepository {
	public static Map<Integer, Luggage> map= new HashMap<>();
	
	static {
		 
	map.put(123, new Luggage(10,250,5000,150,150,5300));
	map.put(153, new Luggage(20,650,89000,850,750,5300));
	map.put(183, new Luggage(30,690,9000,650,740,5300));
	
	
	}
	public static Map<Integer, Luggage> getMap() {
		return map;
	}
	public static void setMap(Map<Integer, Luggage> map) {
		LuggageRepository.map = map;
	}

}
