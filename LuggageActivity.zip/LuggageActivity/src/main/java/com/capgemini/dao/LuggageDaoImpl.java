package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.capgemini.beans.Luggage;
import com.capgemini.exception.LuggageException;
import com.capgemini.utility.LuggageRepository;

public class LuggageDaoImpl implements LuggageDao {
	LuggageRepository utility= new LuggageRepository();
	@Override
	public boolean addWeight(int id, Luggage luggage) throws LuggageException {
		LuggageRepository.map.put(id, luggage);
		return true ;
	}
	@Override
	public Map<Integer, Luggage> getList() throws LuggageException {
		// TODO Auto-generated method stub
		return LuggageRepository.map;
	}
	@Override
	public List<Luggage> getListById(int id) throws LuggageException {
       List<Luggage> list = new ArrayList<>();
       Set<Integer> set=LuggageRepository.map.keySet();
       Iterator<Integer> iterator= set.iterator();
       while(iterator.hasNext()) {
    	   int Id=iterator.next();
    	   if(id==Id) {
    		   Luggage luggage=LuggageRepository.map.get(Id);
    		   list.add(luggage);
    	   }
       }
		return list;
	}

}
