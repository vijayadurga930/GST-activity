package com.capgemini.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.beans.Luggage;
import com.capgemini.exception.LuggageException;

public interface LuggageDao {

	boolean addWeight(int id, Luggage luggage)throws LuggageException;

	Map<Integer, Luggage> getList()throws LuggageException;

	List<Luggage> getListById(int id)throws LuggageException;

}
