package com.capgemini.beans;

public class Luggage {
private float weight;
private float distance;
private int id;
private double charge;
private double CGST;
private double SGST;
private double TotalCharge;
public Luggage() {
	super();
	// TODO Auto-generated constructor stub
}
public Luggage(float weight, float distance, double charge, double cGST, double sGST, double totalCharge) {
	super();
	this.weight = weight;
	this.distance = distance;
	this.charge = charge;
	CGST = cGST;
	SGST = sGST;
	TotalCharge = totalCharge;
}
public float getWeight() {
	return weight;
}
public void setWeight(float weight) {
	this.weight = weight;
}
public float getDistance() {
	return distance;
}
public void setDistance(float distance) {
	this.distance = distance;
}
public double getCharge() {
	return charge;
}
public void setCharge(double charge) {
	this.charge = charge;
}
public double getCGST() {
	return CGST;
}
public void setCGST(float cGST) {
	CGST = cGST;
}
public double getSGST() {
	return SGST;
}
public void setSGST(float sGST) {
	SGST = sGST;
}
public double getTotalCharge() {
	return TotalCharge;
}
public void setTotalCharge(double totalCharge) {
	TotalCharge = totalCharge;
}

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Override
public String toString() {
	return "weight=" + weight + ", distance=" + distance + ", charge=" + charge + ", CGST=" + CGST + ", SGST="
			+ SGST + ", TotalCharge=" + TotalCharge + "\n";
}

}
