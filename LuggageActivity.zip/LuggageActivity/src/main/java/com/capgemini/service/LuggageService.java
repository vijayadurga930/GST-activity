package com.capgemini.service;

import java.util.List;
import java.util.Map;

import com.capgemini.beans.Luggage;
import com.capgemini.exception.LuggageException;

public interface LuggageService {

	boolean validateWeight(float weight)throws LuggageException;

	boolean validateDistance(float distance)throws LuggageException;

	double charge(float weight, float distance)throws LuggageException;

	double Tax(double charge)throws LuggageException;

	double getTotalCharge(double charge, double cGSt, double sGST)throws LuggageException;

	int getGeneratedId()throws LuggageException;

	boolean addWeight(int id, Luggage luggage)throws LuggageException;

	Map<Integer, Luggage> getList()throws LuggageException;

	List<Luggage> getListById(int id)throws LuggageException;

}
