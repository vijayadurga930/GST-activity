package com.capgemini.service;

import java.util.List;
import java.util.Map;

import com.capgemini.beans.Luggage;
import com.capgemini.dao.LuggageDao;
import com.capgemini.dao.LuggageDaoImpl;
import com.capgemini.exception.LuggageException;

public class LuggageServiceImpl implements LuggageService {
	LuggageDao  dao= new LuggageDaoImpl();

	@Override
	public boolean validateWeight(float weight) throws LuggageException {
		boolean validateWeight=false;
		if(weight>1)
			validateWeight=true;
		else
			throw new LuggageException("weight must be greater than 1 kg");
		return validateWeight;
	}

	@Override
	public boolean validateDistance(float distance) throws LuggageException {
		boolean validateDistance=false;
		if(distance>100)
			validateDistance=true;
		else
			throw new LuggageException("distance must be greater than 100 Km");
		return validateDistance;
	}

	@Override
	public double charge(float weight, float distance) throws LuggageException {
		double charge=0;
		charge=weight*(distance*2);
		return charge;
	}

	@Override
	public double Tax(double charge) throws LuggageException {
		double tax=0;
		tax=charge*(3.25/100);
		return tax;
	}

	@Override
	public double getTotalCharge(double charge, double cGSt, double sGST) throws LuggageException {
		// TODO Auto-generated method stub
		double totalCharge=0;
		totalCharge=charge+cGSt+sGST;
		return totalCharge;
	}

	@Override
	public int getGeneratedId() throws LuggageException {
		double generatedId=0;
		generatedId=Math.random()*1000;
		int id=(int)generatedId;


		return id;
	}

	@Override
	public boolean addWeight(int id, Luggage luggage) throws LuggageException {
		// TODO Auto-generated method stub
		return dao.addWeight(id,luggage);
	}

	@Override
	public Map<Integer, Luggage> getList() throws LuggageException {
		// TODO Auto-generated method stub
		return dao.getList();
	}

	@Override
	public List<Luggage> getListById(int id) throws LuggageException {
		// TODO Auto-generated method stub
		return dao.getListById(id);
	}

}
