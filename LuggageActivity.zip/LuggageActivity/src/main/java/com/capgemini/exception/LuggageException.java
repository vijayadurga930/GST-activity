package com.capgemini.exception;

public class LuggageException extends Exception
{

	public LuggageException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
