package com.capgemini.LuggageActivity;
import com.capgemini.beans.Luggage;

import junit.framework.TestCase;

public class LuggageserviceimplTest extends TestCase {
Luggage luggage= new Luggage();
	public void testValidateWeight() {
	
	}

	public void testValidateDistance() {
		fail("Not yet implemented");
	}

	public void testCharge() {
		fail("Not yet implemented");
	}

	public void testGetGeneratedId() {
		fail("Not yet implemented");
	}

}
