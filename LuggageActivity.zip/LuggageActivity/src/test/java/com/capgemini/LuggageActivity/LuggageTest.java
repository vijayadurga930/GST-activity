package com.capgemini.LuggageActivity;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.beans.Luggage;
import com.capgemini.exception.LuggageException;
import com.capgemini.service.LuggageService;
import com.capgemini.service.LuggageServiceImpl;

public class LuggageTest {
static LuggageService service;
Luggage luggage;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		service=new LuggageServiceImpl();
		}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		service=null;
	}

	@Before
	public void setUp() throws Exception {
		luggage=new Luggage(100,101, 0, 0, 0, 0);
	}

	@After
	public void tearDown() throws Exception {
		luggage=null;
	}

	@Test
	public void testValidateWeight() {
		try {
			assertFalse(service.validateWeight(0.5f));
		} catch (LuggageException e) {
			// TODO Auto-generated catch block
			
		}
	}
	@Test(expected=LuggageException.class)
	public void testValidateWeightException() throws LuggageException {

			service.validateWeight(0);
		
	}
	
	@Test
	public void testValidateWeightNegative() {
		try {
			
			assertFalse(service.validateWeight(0));
		} catch (LuggageException e) {
			
		}
	}


	@Test
	public void testValidateDistance() {
		fail("Not yet implemented");
	}

	@Test
	public void testCharge() {
		fail("Not yet implemented");
	}

	@Test
	public void testTax() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetGeneratedId() {
		fail("Not yet implemented");
	}

}
