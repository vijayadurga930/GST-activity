package com.cg.oi.Dao;
import java.util.Map;

import com.cg.oi.Oiexception.OIException;
import com.cg.oi.beans.Item;
public interface ItemDAO {
	public Map<Integer, Item> getItems()throws OIException;

	public int orderId()throws OIException;

	public double addAmount(double amnt)throws OIException;
}
