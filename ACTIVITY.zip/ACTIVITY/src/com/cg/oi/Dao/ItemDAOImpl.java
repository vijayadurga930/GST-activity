package com.cg.oi.Dao;

import java.util.Map;

import com.cg.oi.Oiexception.OIException;
import com.cg.oi.beans.Item;
import com.cg.oi.utility.ItemRepositories;

public class ItemDAOImpl implements ItemDAO {
	ItemRepositories db= new ItemRepositories();

	@Override
	public Map<Integer, Item> getItems() throws OIException {
		// TODO Auto-generated method stub
		return db.itemList;
	}

	@Override
	public int orderId() throws OIException {
		// TODO Auto-generated method stub
		double Id=Math.random()*1000;
		int orderId=(int)Id;
		return orderId;
	}

	@Override
	public double addAmount(double amnt) throws OIException {


		return 0;
	}
	

}
