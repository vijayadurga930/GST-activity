package com.cg.oi.beans;

public class Order {
	private int orderId;
	private double price;
	private int itemId;
	private int quantity;
	private double amnt;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int orderId, double price, int itemId, int quantity,double amnt1) {
		super();
		this.orderId = orderId;
		this.price = price;
		this.itemId = itemId;
		this.quantity = quantity;
		this.amnt=amnt1;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public double getAmnt() {
		return amnt;
	}
	public void setAmnt(double amnt) {
		this.amnt = amnt;
	}
	@Override
	public String toString() {
		return "  orderId =" + orderId + ", price=" + price + ", itemId=" + itemId + ", quantity=" + quantity +" amnt is "+amnt+ "\n";
	}
	
}
